package com.sqlite.implementation;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.opencsv.CSVReader;
import com.sqlite.columns.AllColumns;

@SpringBootApplication
public class ColumnsWithSQLite implements CommandLineRunner {
	
	class StaticsForLogMapper implements RowMapper<AllColumns> {
		
		@Override
		public AllColumns mapRow(ResultSet rs, int rowNum) throws SQLException {
			AllColumns columns = new AllColumns();
			columns.setCustomerId(rs.getLong("customerId"));
			columns.setA(rs.getString("A"));
			columns.setB(rs.getString("B"));
			columns.setC(rs.getString("C"));
			columns.setD(rs.getString("D"));
			columns.setE(rs.getString("E"));
			columns.setF(rs.getString("F"));
			columns.setG(rs.getString("G"));
			columns.setH(rs.getString("H"));
			columns.setI(rs.getString("I"));
			columns.setJ(rs.getString("J"));
			return columns;
		}
	}

	private static final CharSequence HEADER = "A,B,C,D,E,F,G,H,I,J";

	private static final CharSequence LINE_SEPARATOR = "\n";

	private static final CharSequence COMMA_DELIMITER = ",";
	
	private Logger logger = LoggerFactory.getLogger("Statistics.log");

	public static void main(String[] args) {
		SpringApplication.run(ColumnsWithSQLite.class, args);
	}
	@Autowired
	JdbcTemplate format;
	
	@Override
	public void run(String... args) throws Exception {
		InputStream csvinputData = getClass().getClassLoader().getResourceAsStream("ms3Interview.csv");
		InputStreamReader csvinputDataStream = new InputStreamReader(csvinputData);
		Reader bufReader = new BufferedReader(csvinputDataStream);
		CSVReader csv = new CSVReader(bufReader);
		int noOfReceived=0;
		int noOfFailed = 0;
		String[] next;	
		next = csv.readNext();
		while ((next = csv.readNext()) != null && next.length >1) {
			noOfReceived++;
			insert(next,noOfFailed);
		}
		logMethod(noOfReceived,getTotalRecords(),noOfFailed  );
		csv.close();
	}

	private void insert(String[] next,int noOfFailed){
		try{
			insert(new AllColumns(check(next[0]), check(next[1]), check(next[2]), 
					check(next[3]), check(next[4]), check(next[5]),check(next[6]),
					check(next[7]), check(next[8]), check(next[9])));
		}catch(Exception e){
			noOfFailed++;
			List empList = new ArrayList();
			for(int i=0; i<10;i++) {
				empList.add(next[i]);
			}
			newcsv(empList);
			
		}
	}
	
	private void logMethod(int noOfReceived, int noOfSuccess,int noOfFailed) {
		logger.info("# of records received"+ noOfReceived);
		logger.info("# of records successfull"+ noOfSuccess);
		logger.info("# of records failed"+ noOfFailed);
	}
	
	private String check(String column){		
		if(StringUtils.isBlank(column)){
			return null;
		}else{
			return column;
		}
	}
	public List<AllColumns> findAll() {
		return format.query("SELECT * FROM MS3CUSTOMERS", new StaticsForLogMapper());
	}

	public Integer getTotalRecords() {
		return format.queryForObject("SELECT COUNT(*) FROM MS3CUSTOMERS", Integer.class);
	}

	public int insert(AllColumns columns) {
		return format.update("INSERT INTO MS3CUSTOMERS (A, B, C, D, E, F, G, H, I, J) " + "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
				new Object[] { columns.getA(),columns.getB(), 
						columns.getC(),columns.getD(), columns.getE(),columns.getF(),
						columns.getG(),columns.getH(), columns.getI(),columns.getJ()});
	}
	
	public void newcsv(List empList) {
		try
    	{
			FileWriter fileWriter = new FileWriter("src/main/resources/01:11:2019.csv");
    		
    		fileWriter.append(HEADER);
    		fileWriter.append(LINE_SEPARATOR);
    		Iterator it = empList.iterator();
    		while(it.hasNext())
    		{
    			for(int i=0; i< 10;i++) {
    		
    			fileWriter.append((CharSequence) empList.get(i));
    			}
    		}
    	}catch(Exception ee)
    	{
    		ee.printStackTrace();
    	}
	}
}
